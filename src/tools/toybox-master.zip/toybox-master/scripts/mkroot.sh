#!/usr/bin/printf Moved to mkroot/mkroot.sh\n\c%s
